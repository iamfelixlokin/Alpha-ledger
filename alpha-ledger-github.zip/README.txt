Alpha 刷分帳本 — GitHub Pages 架設說明

檔案
  alpha-ledger-site/   要上傳到 GitHub 的整個資料夾內容
  my-data.json         你 2025-09 至今的紀錄，預設不上傳

步驟
1. 到 github.com 登入，右上角 + → New repository。
   Repository name 填 alpha-ledger，選 Public，其他不用勾，按 Create repository。

2. 在新 repo 頁面按 uploading an existing file，
   把 alpha-ledger-site 資料夾「裡面的 8 個檔案」全選拖進去（不要拖資料夾本身），
   下方按 Commit changes。

3. 進 Settings → 左邊 Pages → Build and deployment
   Source 選 Deploy from a branch
   Branch 選 main，資料夾選 / (root)，按 Save。

4. 等一到兩分鐘重新整理，頁面上方會出現網址：
   https://你的帳號.github.io/alpha-ledger/

5. iPhone 用 Safari 開那個網址（一定要 Safari，Chrome 不行），
   按下方分享鍵 → 加入主畫面。

6. 第一次開啟時匯入資料：點「匯入 JSON」，選 my-data.json。
   資料存在手機瀏覽器裡，不會上傳。

關於 my-data.json
  Public repo 的檔案任何人拿到網址都看得到。
  不想公開每日成本和空投金額，就照步驟 6 手動匯入。
  不介意公開的話，把 my-data.json 改名成 data.json 一起上傳，
  之後在新裝置開啟會自動載入，不用手動匯入。

更新頁面
  之後若換新版 index.html，重新上傳覆蓋後，
  要一併把 sw.js 裡的 CACHE = "alpha-ledger-v1" 改成 v2，
  否則手機會繼續用舊的快取。
